import { useEffect, useState } from "react";
import api from "../api";

const Dashboard = () => {
  const [tasks, setTasks] = useState([]);
  const [form, setForm] = useState({
    title: "",
    description: "",
    status: "todo",
    priority: "medium"
  });

  const loadTasks = async () => {
    const res = await api.get("/tasks");
    setTasks(res.data);
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const handleChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleCreate = async (e) => {
    e.preventDefault();
    await api.post("/tasks", form);
    setForm({ title: "", description: "", status: "todo", priority: "medium" });
    loadTasks();
  };

  const cycleStatus = (status) => {
    if (status === "todo") return "in-progress";
    if (status === "in-progress") return "done";
    return "todo";
  };

  const handleUpdate = async (task) => {
    const newStatus = cycleStatus(task.status);
    await api.put(`/tasks/${task._id}`, { status: newStatus });
    loadTasks();
  };

  const handleDelete = async (id) => {
    await api.delete(`/tasks/${id}`);
    loadTasks();
  };

  return (
    <div>
      <h2>My Tasks - SecureTask Hub</h2>

      <form onSubmit={handleCreate}>
        <input
          name="title"
          placeholder="Task title"
          value={form.title}
          onChange={handleChange}
          required
        />
        <input
          name="description"
          placeholder="Task description"
          value={form.description}
          onChange={handleChange}
        />
        <button type="submit">Add Task</button>
      </form>

      <div>
        {tasks.map((t) => (
          <div key={t._id} style={{ border: "1px solid #ccc", margin: "8px", padding: "8px" }}>
            <h3>{t.title}</h3>
            <p>{t.description}</p>
            <p>Status: {t.status}</p>
            <p>Priority: {t.priority}</p>
            <button onClick={() => handleUpdate(t)}>Next Status</button>
            <button onClick={() => handleDelete(t._id)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
