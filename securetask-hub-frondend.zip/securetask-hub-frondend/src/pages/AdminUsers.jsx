import { useEffect, useState } from "react";
import api from "../api";

const AdminUsers = () => {
  const [users, setUsers] = useState([]);

  const loadUsers = async () => {
    const res = await api.get("/users"); // backend rejects non-admin
    setUsers(res.data);
  };

  useEffect(() => {
    loadUsers();
  }, []);

  return (
    <div>
      <h2>All Users (Admin only)</h2>
      <p>If you are not admin, backend will reject this operation.</p>
      <ul>
        {users.map((u) => (
          <li key={u._id}>
            {u.email} - {u.name} - {u.role}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminUsers;
