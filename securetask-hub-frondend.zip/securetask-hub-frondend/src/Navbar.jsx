import { Link } from "react-router-dom";
import { useAuth } from "./AuthContext";

const Navbar = () => {
  const { user, logout } = useAuth();

  return (
    <nav style={{ padding: "8px", borderBottom: "1px solid #ccc" }}>
      <span style={{ marginRight: "16px", fontWeight: "bold" }}>
        SecureTask Hub
      </span>
      {user && <Link to="/">Dashboard</Link>}
      {user && user.role === "admin" && (
        <Link to="/admin" style={{ marginLeft: "8px" }}>
          Users
        </Link>
      )}
      {!user && (
        <>
          <Link to="/login" style={{ marginLeft: "8px" }}>
            Login
          </Link>
          <Link to="/register" style={{ marginLeft: "8px" }}>
            Register
          </Link>
        </>
      )}
      {user && (
        <button onClick={logout} style={{ marginLeft: "8px" }}>
          Logout
        </button>
      )}
    </nav>
  );
};

export default Navbar;
