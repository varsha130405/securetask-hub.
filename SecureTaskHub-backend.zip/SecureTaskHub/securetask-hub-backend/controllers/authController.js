const jwt = require("jsonwebtoken");
const User = require("../models/User");

const makeToken = (id, role) => {
  return jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn: "7d" });
};

const registerUser = async (req, res) => {
  const { name, email, password, role } = req.body;

  try {
    const already = await User.findOne({ email });
    if (already) {
      return res.status(400).json({ message: "Email already used" });
    }

    const user = await User.create({ name, email, password, role });
    const token = makeToken(user._id, user.role);

    res.status(201).json({
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token
    });
  } catch (err) {
    res.status(500).json({ message: "Register error" });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    const isMatch = user && (await user.matchPassword(password));

    if (!user || !isMatch) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const token = makeToken(user._id, user.role);

    res.json({
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token
    });
  } catch (err) {
    res.status(500).json({ message: "Login error" });
  }
};

const getMe = (req, res) => {
  res.json(req.user);
};

module.exports = { registerUser, loginUser, getMe };
