const express = require("express");
const {
  createTask,
  getMyTasks,
  updateTask,
  deleteTask
} = require("../controllers/taskController");
const { protect } = require("../mid/auth");

const router = express.Router();

router.use(protect);
router.post("/", createTask);
router.get("/", getMyTasks);
router.put("/:id", updateTask);
router.delete("/:id", deleteTask);

module.exports = router;
